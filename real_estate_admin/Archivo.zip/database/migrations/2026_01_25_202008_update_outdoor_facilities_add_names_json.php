<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('outdoor_facilities', function (Blueprint $table) {
            // Agregar columna JSON para almacenar nombres en múltiples idiomas
            $table->json('names')->nullable()->after('id')->comment('JSON with translations: {en: "...", es: "..."}');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('outdoor_facilities', function (Blueprint $table) {
            $table->dropColumn('names');
        });
    }
};
